function onLoad() {
	changeLogInButton();
	sessionId();
}