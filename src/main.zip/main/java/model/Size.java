package model;

public enum Size {
    SUB_COMPACT,
    COMPACT,
    MID_SIZE,
    LARGE
}
