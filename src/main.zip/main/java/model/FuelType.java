package model;

public enum FuelType {
    GASOLINE,
    DIESEL,
    LPG
}
