package model;

public enum BodyType {
    SEDAN,
    COUPE,
    MINIVAN,
    SUV,
    CROSSOVER,
    HATCHBACK,
    STATION_WAGON,
    OFF_ROADER,
    PICK_UP
}
