package model;

public enum DriveLayout {
    FWD,
    RWD,
    AWD,
    FOURWD
}
